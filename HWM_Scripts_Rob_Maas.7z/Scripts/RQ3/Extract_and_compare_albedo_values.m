% Variables:
disk = 'G';
cmap = gray;

%%% Load required data
box_lims
region_lat = landeslims.regionbox.latlim;
region_lon = landeslims.regionbox.lonlim;

load Data\hrv_grid\hrv_grid;
hrv_lat = landes.hrv_lat;
hrv_lon = landes.hrv_lon;

%%% Strings to loop from 2004-2014
yrs_list = {'2004','2008','2009','2013'};


%%% CORE - extraction of albedo values from every albedo map and storing
%%% the relative difference between forest and non-forest

for y = 1:2
    net_albedo_map = load([disk ':\Thesis\Data\matlab\net_albedo_maps\net_albedo_map_landes_' yrs_list{2*y-1} '_' yrs_list{2*y} '.mat']);
    reg_albedo_map = load([disk ':\Thesis\Data\matlab\reflectance\surface_reflectance_landes_' yrs_list{2*y-1} '_' yrs_list{2*y} '.mat']);
    
    albedo_diff_values = zeros(4*3*12,2);
    i = 1;
    for m = 1:4
        for dec = 1:3
            for h = 1:12
                
                % Load in maps
                reg_map = double(squeeze(reg_albedo_map.surfrefl(m,dec,h,:,:)));
                net_map = double(squeeze(net_albedo_map.surfrefl(m,dec,h,:,:)));
                
                % Normalize
                reg_map_norm = (reg_map - min([min(reg_map(:)) min(net_map(:))]))/(max([max(reg_map(:)) max(net_map(:))])-min([min(reg_map(:)) min(net_map(:))]))*100;
                net_map_norm = (net_map - min([min(reg_map(:)) min(net_map(:))]))/(max([max(reg_map(:)) max(net_map(:))])-min([min(reg_map(:)) min(net_map(:))]))*100;
                
                % Extract mean albedo f and nf and calc difference percentage
                reg_f = mean2(reg_map_norm(64:107,40:65));
                reg_nf = mean2(reg_map_norm(40:84,5:32));
                albedo_diff_values(i,1) = ((reg_nf - reg_f)/reg_f)*100;
                
                net_f = mean2(net_map_norm(64:107,40:65));
                net_nf = mean2(net_map_norm(40:84,5:32));
                albedo_diff_values(i,2) = ((net_nf - net_f)/net_f)*100;
                
                i = i+1;
            end
        end
    end
    if y == 1
        temp_alb_diff_values = albedo_diff_values;
    elseif y == 2
        albedo_diff_values = cat(1,temp_alb_diff_values,albedo_diff_values);
        clear temp_alb_diff_values
    end
end

albedo_diff_values = albedo_diff_values(3:end,:);

%%% PLOT GRAPH

close all
figure

p1 = plot(albedo_diff_values(:,1));
hold on
p2 = plot(albedo_diff_values(:,2));

% lims
xlim([0 size(albedo_diff_values,1)]);

% Shade area
xlims = [34 46];
ylims = get(gca, 'ylim');
patch([xlims(1) xlims(2) xlims(2) xlims(1)], [ylims(1) ylims(1) ylims(2) ylims(2)],'k','FaceAlpha',.5,'EdgeColor','none');

%%% Labels etc
legend([p1 p2],{'Regular albedo','Net albedo'})
ylabel('Albedo difference [%]');
% xlabel('Timestep');

%%% Xlabels - months
x_labels_months = {'May','June','July','August','May','June','July','August'};
x_ticks_months = 34:36:286;
x_tick_diff = x_ticks_months(2) - x_ticks_months(1);
x_tick_label_positions = x_ticks_months - 0.6*x_tick_diff;

xticks(x_ticks_months);

% Use text to display months at right loc
for i=1:length(x_tick_label_positions)
    text(x_tick_label_positions(i),ylims(1)-1,x_labels_months(i)); 
end

set(gca,'XTickLabel',{}); % make old labels invis

%%% Xlabels - ticks for dec
x_ticks_dec = 10:12:274;

for i=1:length(x_ticks_dec)
    line([x_ticks_dec(i) x_ticks_dec(i)], [ylims(1) ylims(1)+0.5],'Color','k');
end

%%% Xlabels - years
text(x_ticks_months(2)-x_tick_diff*0.2, ylims(1)-5,'2004 - 2008','FontSize',11,'FontWeight','Bold');
text(x_ticks_months(6)-x_tick_diff*0.2, ylims(1)-5,'2009 - 2013','FontSize',11,'FontWeight','Bold');
line([x_ticks_months(4) x_ticks_months(4)], [ylims(1) ylims(1)+3],'Color','k','LineWidth',3);
hold off





%%%%%% PLOT MAPS %%%%
%%%%%%
% %%% Plot the two maps together
y_p = 1;    % 1 for 2004-2008, 2 for 2009-2013
m_p = 1;    % month
dec_p = 2;  % decade
h_p = 8;    % hour

forest_lat = landeslims.forestbox.latlim;
forest_lon = landeslims.forestbox.lonlim;
nonfor1_lat = landeslims.nonforbox1.latlim;
nonfor1_lon = landeslims.nonforbox1.lonlim;
nonfor2_lat = landeslims.nonforbox2.latlim;
nonfor2_lon = landeslims.nonforbox2.lonlim;

% To help find a plot
timestep = (y_p-1)*144 + (m_p-1)*36 + (dec_p-1)*12 + h_p;

net_albedo_map = load([disk ':\Thesis\Data\matlab\net_albedo_maps\net_albedo_map_landes_' yrs_list{2*y_p-1} '_' yrs_list{2*y_p} '.mat']);
reg_albedo_map = load([disk ':\Thesis\Data\matlab\reflectance\surface_reflectance_landes_' yrs_list{2*y_p-1} '_' yrs_list{2*y_p} '.mat']);
p_reg_map = double(squeeze(reg_albedo_map.surfrefl(m_p,dec_p,h_p,:,:)));
p_net_map = double(squeeze(net_albedo_map.surfrefl(m_p,dec_p,h_p,:,:)));

figure

subplot(1,2,1);
axis image;
axesm('MapProjection','lambert','Frame','on','grid','on', 'MapLatLimit',region_lat,'MapLonLimit',region_lon,'FLineWidth',.5);
colormap(cmap);
pcolorm(hrv_lat,hrv_lon,p_reg_map);
title('Regular albedo map');
colorbar

%forestbox:
box1 = linem([max(forest_lat); min(forest_lat);...
    min(forest_lat); max(forest_lat);...
    max(forest_lat)], [min(forest_lon);...
    min(forest_lon); max(forest_lon);...
    max(forest_lon); min(forest_lon)],...
    'Color',[0.2 0.85 0.4], 'LineWidth', 3, 'LineStyle', ':');
box2 = linem([max(nonfor1_lat); min(nonfor1_lat);...
    min(nonfor1_lat); max(nonfor1_lat);...
    max(nonfor1_lat)], [min(nonfor1_lon);...
    min(nonfor1_lon); max(nonfor1_lon);...
    max(nonfor1_lon); min(nonfor1_lon)],...
    'Color',[0 0.8 0.8], 'LineWidth', 3);
l = legend([box1 box2], 'Forest','Nonforest1', 'Location','northeast');


subplot(1,2,2);
axis image;
axesm('MapProjection','lambert','Frame','on','grid','on', 'MapLatLimit',region_lat,'MapLonLimit',region_lon,'FLineWidth',.5);
colormap(cmap);
pcolorm(hrv_lat,hrv_lon,p_net_map);
title('Net albedo map');
colorbar
box1 = linem([max(forest_lat); min(forest_lat);...
    min(forest_lat); max(forest_lat);...
    max(forest_lat)], [min(forest_lon);...
    min(forest_lon); max(forest_lon);...
    max(forest_lon); min(forest_lon)],...
    'Color',[0.2 0.85 0.4], 'LineWidth', 3, 'LineStyle', ':');
box2 = linem([max(nonfor1_lat); min(nonfor1_lat);...
    min(nonfor1_lat); max(nonfor1_lat);...
    max(nonfor1_lat)], [min(nonfor1_lon);...
    min(nonfor1_lon); max(nonfor1_lon);...
    max(nonfor1_lon); min(nonfor1_lon)],...
    'Color',[0 0.8 0.8], 'LineWidth', 3);









%%% overbodig

% % Normalize maps
% reg_map_norm = (reg_map - min(reg_map(:)))/(max(reg_map(:))-min(reg_map(:)))*100;
% net_map_norm = (net_map - min(net_map(:)))/(max(net_map(:))-min(net_map(:)))*100;

%%% METHOD 1
% for m = 1:4
%     for dec = 1:3
%         for h = 1:12
%             
%             % Load in maps
%             reg_map = double(squeeze(reg_albedo_map.surfrefl(m,dec,h,:,:)));
%             net_map = double(squeeze(net_albedo_map.surfrefl(m,dec,h,:,:)));
% 
%             % Extract mean albedo f and nf and calc difference percentage
%             reg_f = mean2(reg_map(64:107,40:65));
%             reg_nf = mean2(reg_map(40:84,5:32));
%             albedo_diff_values(i,1) = ((reg_nf - reg_f)/reg_f)*100;
%             
%             net_f = mean2(net_map(64:107,40:65));
%             net_nf = mean2(net_map(40:84,5:32));
%             albedo_diff_values(i,2) = ((net_nf - net_f)/net_f)*100;
%             
%             i = i+1;
%         end
%     end
% end
% 
% 
% close all
% figure
% plot(albedo_diff_values(:,1))
% hold on
% plot(albedo_diff_values(:,2))
% hold off

%%%%%%%%%% METHOD 2

for m = 1:4
    for dec = 1:3
        for h = 1:12
            
            % Load in maps
            reg_map = double(squeeze(reg_albedo_map.surfrefl(m,dec,h,:,:)));
            net_map = double(squeeze(net_albedo_map.surfrefl(m,dec,h,:,:)));
            
            % Normalize
            reg_map_norm = (reg_map - min(reg_map(:)))/(max(reg_map(:))-min(reg_map(:)))*100;
            net_map_norm = (net_map - min(net_map(:)))/(max(net_map(:))-min(net_map(:)))*100;

            % Extract mean albedo f and nf and calc difference percentage
            reg_f = mean2(reg_map_norm(64:107,40:65));
            reg_nf = mean2(reg_map_norm(40:84,5:32));
            albedo_diff_values(i,1) = ((reg_nf - reg_f)/reg_f)*100;
            
            net_f = mean2(net_map_norm(64:107,40:65));
            net_nf = mean2(net_map_norm(40:84,5:32));
            albedo_diff_values(i,2) = ((net_nf - net_f)/net_f)*100;
            
            i = i+1;
        end
    end
end

close all
figure
p1 = plot(albedo_diff_values(:,1));
hold on
p2 = plot(albedo_diff_values(:,2));
hold off

legend(p1)


% %%% METHOD 4
% 
% for y = 1:2
%     net_albedo_map = load([disk ':\Thesis\Data\matlab\net_albedo_maps\net_albedo_map_landes_' yrs_list{2*y-1} '_' yrs_list{2*y} '.mat']);
%     reg_albedo_map = load([disk ':\Thesis\Data\matlab\reflectance\surface_reflectance_landes_' yrs_list{2*y-1} '_' yrs_list{2*y} '.mat']);
%     
%     albedo_diff_values = zeros(4*3*12,2);
%     i = 1;
%     for m = 1:4
%         for dec = 1:3
%             for h = 1:12
%                 
%                 % Load in maps
%                 reg_map = double(squeeze(reg_albedo_map.surfrefl(m,dec,h,:,:)));
%                 net_map = double(squeeze(net_albedo_map.surfrefl(m,dec,h,:,:)));
%                 
%                 % Normalize
%                 reg_map_norm = (reg_map - min([min(reg_map(:)) min(net_map(:))]))/(max([max(reg_map(:)) max(net_map(:))])-min([min(reg_map(:)) min(net_map(:))]))*100;
%                 net_map_norm = (net_map - min([min(reg_map(:)) min(net_map(:))]))/(max([max(reg_map(:)) max(net_map(:))])-min([min(reg_map(:)) min(net_map(:))]))*100;
%                 
%                 % Extract mean albedo f and nf and calc difference percentage
%                 reg_f = mean2(reg_map_norm(64:107,40:65));
%                 reg_nf = mean2(reg_map_norm(40:84,5:32));
%                 albedo_diff_values(i,1) = reg_nf - reg_f;
%                 
%                 net_f = mean2(net_map_norm(64:107,40:65));
%                 net_nf = mean2(net_map_norm(40:84,5:32));
%                 albedo_diff_values(i,2) = net_nf - net_f;
%                 
%                 i = i+1;
%             end
%         end
%     end
%     if y == 1
%         temp_alb_diff_values = albedo_diff_values;
%     elseif y == 2
%         albedo_diff_values = cat(1,temp_alb_diff_values,albedo_diff_values);
%         clear temp_alb_diff_values
%     end
% end
% 
% 
% close all
% figure
% p1 = plot(albedo_diff_values(:,1));
% hold on
% p2 = plot(albedo_diff_values(:,2));
% hold off
% 
% legend([p1 p2],{'reg','net'})
% 
