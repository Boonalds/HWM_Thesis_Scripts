function [] = makefigure(size1,size2)

% MAKEFIGURE   makes figure window.
%    MAKEFIGURE creates window with default size
%    MAKEFIGURE(SIZE) creates window with height SIZE and width 8.5cm
%    MAKEFIGURE(WIDTH,HEIGHT) creates window with height and widht in cm

default_width = 8.5; % cm
default_height = 6; % cm

if nargin == 0
    width = default_width;
    height = default_height;
elseif nargin == 1
    width = default_width;
    height = size1;
elseif nargin == 2
    width = size1;
    height = size2;
end

figure;
hold on
set(gcf,'PaperUnits','Centimeters','PaperSize',[width height],...
    'paperposition',[0 0 width height]);
set(gca,'Position',[.15 .19 .81 .75])
