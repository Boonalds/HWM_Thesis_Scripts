europe.regionbox.latlim = [42 51];
europe.regionbox.lonlim = [-5 8.5];

landes.regionbox.latlim = [43.45 45.2];
landes.regionbox.lonlim = [-1.7 .8];
landes.forestbox.latlim = [44 44.4];
% landes.forestbox.lonlim = [-.9 -.3];
landes.forestbox.lonlim = [-.6 0];
landes.nonforbox1.latlim = [43.5 43.9];
landes.nonforbox1.lonlim = [-.3 .3];
landes.nonforbox2.latlim = [44.6 45];
landes.nonforbox2.lonlim = [-.7 -.1];
% landes.nonforbox3.latlim = [44.4 44.8];
% landes.nonforbox3.lonlim = [.1 .7];

landes.forestboxklaus.latlim = [43.85 44.25];
% landes.forestbox.lonlim = [-.9 -.3];
landes.forestboxklaus.lonlim = [-1 -.4];


orleans.regionbox.latlim = [46.625 48.375];
orleans.regionbox.lonlim = [.75 3.25];
orleans.forestbox.latlim = [47.3 47.7];
orleans.forestbox.lonlim = [1.7 2.3];
% orleans.nonforbox1.latlim = [46.9 47.3];
% orleans.nonforbox1.lonlim = [2.4 3];
orleans.nonforbox1.latlim = [47.3 47.7];
orleans.nonforbox1.lonlim = [2.4 3];
orleans.nonforbox2.latlim = [47.1 47.5];
orleans.nonforbox2.lonlim = [0.9 1.5];
% orleans.nonforbox2.latlim = [46.8 47.2];
% orleans.nonforbox2.lonlim = [1.4 2];
% orleans.nonforbox3.latlim = [47.9 48.3];
% orleans.nonforbox3.lonlim = [1.3 1.9];


% veluwe.forestbox.latlim = [52 52.4];
% veluwe.forestbox.lonlim = [5.6 6];
% veluwe.nonforbox1.latlim = [52 52.4];
% veluwe.nonforbox1.lonlim = [6.1 6.5];
% veluwe.nonforbox2.latlim = [43.3 43.7];
% veluwe.nonforbox2.lonlim = [-.9 -.3];