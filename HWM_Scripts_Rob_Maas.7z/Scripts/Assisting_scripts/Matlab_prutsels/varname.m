function out = varname(var)
box_lims
  out = inputname(1);
  min(varname([regionname 'lims.forestbox.latlim']))
end

