load Data\matlab\cloud_formation_times\cloud_form_dates_60_10

